<?php get_header(); ?>


<!-- Learn Banner Start -->
	<section class="learn-banner">
		<div class="container">
			<div class="row">
				<div class="col-md-12 page-heading">
					<h1>Questions & Answers</h1>
				</div>
			</div>
		</div>
	</section>
<!-- Learn Banner End -->
<!----faq list section--->
<section class="faq-list mb-5 mt-3">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<h2>
					Articles Help Center
				</h2>
				<div class="faq-box pricing-table">				
					<h6>
				     i have a part-145 company that i would like to setup with your service?
				</h6>
				<p>
					Not a problem,Sign up for the 30 days free trail account for the busniesses and if you are satisfied                       you can explore the subscription plans available.
				</p>
				 <div class="divider"> </div>
				<h6>
					Do i need to enter my credit card details to sign up?
				</h6>
				<p>
					Not a problem,Sign up for the 30 days free trail account for the busniesses and if you are satisfied                       you can explore the subscription plans available.
				</p>
				</div>
			</div>
		</div>
	</div>
      
</section>
<!---faq list section end---->
<!-----get section start---->
	<section class="get-in-touch">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xl-5 col-md-6 text">
					<h1>Get in touch with <span>our friendly team.</span></h1>
					<p>A wealth of styles and elements makes Ollie perfect for building websites for small, medium and large businesses.</p>
					
				</div>
				<div class="col-xl-5 col-md-6 form skyhook-primary-button">
					<?php echo do_shortcode('[contact-form-7 id="6" title="Get in Touch"]'); ?>
				</div>
			</div>
		</div>
	</section>
</section>
<!-----get section end------>
<?php
get_footer();