<section class="get-in-touch pricing">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5 col-md-6 text">
                <h1>Get in touch with <span>our friendly team.</span></h1>
                <p>A wealth of styles and elements makes Ollie perfect for building websites for small, medium and large
                    businesses.</p>
            </div>
            <div class="col-xl-5 col-md-6 form skyhook-primary-button">
                <?php echo do_shortcode('[contact-form-7 id="6" title="Get in Touch"]'); ?>
            </div>
        </div>
    </div>
</section>
