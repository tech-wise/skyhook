<?php get_header(); ?>

	<div class="error-404 not-found default-max-width my-5 py-5">
		<div class="page-content text-center mb-5 pb-5">
			<h1>404 Page not found</h1>
		</div><!-- .page-content -->
	</div><!-- .error-404 -->

<?php
get_footer();
