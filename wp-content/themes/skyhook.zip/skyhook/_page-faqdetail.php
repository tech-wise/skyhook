<?php
get_header();
?>

<!-- Learn Banner Start
	<section class="learn-banner">
		<div class="container">
			<div class="row">
				<div class="col-md-12 page-heading">
					<h1>Questions & Answers</h1>
				</div>
			</div>
		</div>
	</section>--->
<!-- Learn Banner End -->

<!--faq list start
<section class="faq-list">
    <div class="container">
        <div class="row">
            <div calss="col-md-8">
                <h1>Articles Help Center</h1>
                <div class="faq-box">
                    <h2></h2>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</section>--->
<!--faq list end-->
<!-- Learn Banner Start -->
	<section class="learn-banner">
		<div class="container">
			<div class="row">
				<div class="col-md-12 page-heading">
					<h1>Questions & Answers</h1>
				</div>
			</div>
		</div>
	</section>
<!-- Learn Banner End -->
<!----faq list section--->
<section class="faq-list mt-5">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<h1>Articles Help Center</h1>
				   <div class="faq-box">				
					 <h4>i have a part-145 company that i would like to setup with your service?</h4>
				     <p>Not a problem,Sign up for the 30 days free trail account for the busniesses and if you are                                 satisfied you can explore the subscription plans available.</p>
				 <div class="divider"> 
			     </div>
		     </div>
		</div>
			<div class="col-md-4 flex">
				 <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/7ht_24.png" class="img-fluid">
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="box-list pb-4">
				     <h4>Do i need to enter my credit card details to sign up?</h4>
				      <p>Not a problem,Sign up for the 30 days free trail account for the busniesses and if you are
					     satisfied you can explore the subscription plans available.</p>
			    </div>
			</div>
		</div>
	</div>
	
      
</section>
<!---faq list section end---->
<!-----get section start---->
	<section class="get-in-touch pricing">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5 col-md-6 text">
                <h1>Get in touch with <span>our friendly team.</span></h1>
                <p>A wealth of styles and elements makes Ollie perfect for building websites for small, medium and large
                    businesses.</p>
            </div>
            <div class="col-xl-5 col-md-6 form skyhook-primary-button">
                <?php echo do_shortcode('[contact-form-7 id="6" title="Get in Touch"]'); ?>
            </div>
        </div>
    </div>
</section>

<!-----get section end------>
<!-----get section end------>

<?php
get_footer();


?>